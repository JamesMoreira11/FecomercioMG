﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;
using System.Data;
using Moq;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class BoletoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public BoletoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult GerarBoletos(GerarBoleto Faturamento)
        {
            int idCliente = 0;
            string AnoMes = "";
            string mensagem = "";

            Boleto boleto = new Boleto();
            BoletoDetalhe boletoDetalhe = new BoletoDetalhe();

            if (Faturamento.RazaoSocial == null)
                return BadRequest("Nome do Cliente precisa ser informado");

            if (Faturamento.Mes <= 0 || Faturamento.Mes > 12)
                return BadRequest("Mês de referência inválido !");

            if (Faturamento.Ano <= 1901 || Faturamento.Ano > DateTime.Today.Year)
                return BadRequest("Ano de referência inválido !");

            AnoMes = Faturamento.Ano.ToString() + Faturamento.Mes.ToString().PadLeft(2,'0');

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadoscliente = Banco.ConsultarCliente(Faturamento.RazaoSocial);

            if (dadoscliente != null)
            {
                idCliente = dadoscliente.IdCliente;
                boleto.IdCliente = idCliente;
                boleto.QtdeFuncionarios = dadoscliente.QtdeFuncionarios;
                boleto.CapitalSocial = dadoscliente.CapitalSocial;
            }
            else
            {
                return BadRequest("Cliente não cadastrado !");
            }

            var dadosboleto = Banco.ObterBoleto(idCliente, AnoMes);

            if (dadosboleto != null)
            {
                return BadRequest("Boleto do mês de referência já gerado !");
            }

            boleto.IdBoleto = 0;
            boleto.AnoMes = AnoMes;
            boleto.CodStatus = 1;
            boleto.ValorBoleto = 0;
            boleto.ValorPago = 0;
            boleto.ValorAberto = 0;
            boleto.ValorAdicional = 0;
            boleto.DataVencimento = DateTime.Now.AddDays(30).ToString("dd/MM/yyyy");
            boleto.DataPagamento = "";

            var dados = Banco.PesquisarProdutoCliente(idCliente);

            if (dados != null)
            {
                Banco.GravarBoleto(boleto);

                dadosboleto = Banco.ObterBoleto(idCliente, AnoMes);

                if (dadosboleto == null)
                {
                    return BadRequest("Problemas na geração do Boleto !");
                }

                boleto.IdBoleto = dadosboleto.IdBoleto;

                if (dadoscliente != null)
                {
                    idCliente = dadoscliente.IdCliente;
                    boleto.IdCliente = idCliente;
                    boleto.QtdeFuncionarios = dadoscliente.QtdeFuncionarios;
                    boleto.CapitalSocial = dadoscliente.CapitalSocial;
                }

                for (int i = 0; i < dados.Count(); i++)
                {
                    boletoDetalhe = new BoletoDetalhe();
                    boletoDetalhe.IdBoleto = boleto.IdBoleto;
                    boletoDetalhe.IdCliente = idCliente;
                    boletoDetalhe.IdProduto = dados[i].IdProduto;
                    boletoDetalhe.AnoMes = AnoMes;
                    boletoDetalhe.QtdeFuncionarios = boleto.QtdeFuncionarios;
                    boletoDetalhe.CapitalSocial = boleto.CapitalSocial;
                    boletoDetalhe.IdIndicador = 1;

                    var dadosFunc = Banco.ObterPrecoProduto(boletoDetalhe.IdProduto, boletoDetalhe.IdIndicador, boleto.QtdeFuncionarios);
                    
                    if (dadosFunc != null)
                    {
                        boletoDetalhe.ValorFaturado = dadosFunc.Valor;
                        boleto.ValorBoleto = boleto.ValorBoleto + boletoDetalhe.ValorFaturado;
                        Banco.GravarDetalheBoleto(boletoDetalhe);
                    }

                    boletoDetalhe.IdIndicador = 2;

                    dadosFunc = Banco.ObterPrecoProduto(boletoDetalhe.IdProduto, boletoDetalhe.IdIndicador, boleto.CapitalSocial);

                    if (dadosFunc != null)
                    {
                        boletoDetalhe.ValorFaturado = dadosFunc.Valor;
                        boleto.ValorBoleto = boleto.ValorBoleto + boletoDetalhe.ValorFaturado;
                        Banco.GravarDetalheBoleto(boletoDetalhe);
                    }
                }

                boleto.ValorAberto = boleto.ValorBoleto;
                boleto.ValorAdicional = 0;

                Banco.AtualizarBoleto(boleto);
                mensagem = "Boleto " + boleto.IdBoleto.ToString() + " - Vencimento : " + boleto.DataVencimento + " - Valor : " + boleto.ValorBoleto.ToString("N2");
            }
            return Ok(mensagem);
        }

    }
}
