﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class CategoriaController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public CategoriaController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult CadastrarCategoria(CadastrarCategorias Categorias)
        {
            string mensagem = "";

            if (Categorias.Categoria == null)
                return BadRequest("Descrição da categoria precisa ser informada");

            if (Categorias.Comissao <= 0)
                return BadRequest("Percentual comissão invalido");

            if (Categorias.Comissao >= 100)
                return BadRequest("Percentual comissão não pode ser maior que 100%");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dados = Banco.ConsultarCategoria(Categorias.Categoria);

            if (dados != null)
            {
                Banco.AtualizarCategoria(Categorias.Categoria, Categorias.Comissao);
                mensagem = "Categoria " + dados.IdCategoria.ToString() + " - " + Categorias.Categoria + ", atualizada com sucesso";
            }
            else
            {
                Banco.GravarCategoria(Categorias.Categoria, Categorias.Comissao);
                mensagem = "Categoria " + Categorias.Categoria + " incluida com sucesso";
            }

            return Ok(mensagem);
        }
    }
}
