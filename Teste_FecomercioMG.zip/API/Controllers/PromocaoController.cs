﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class PromocaoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public PromocaoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult PromocaoProduto(CadastrarPromocao Promocao)
        {
            int idProduto = 0;
            string mensagem = "";

            if (Promocao.Produto == null)
                return BadRequest("Descrição do produto precisa ser informada");

            if (Promocao.Comissao <=0)
                return BadRequest("Percentual de comissão inválido !");

            if (Promocao.Comissao >= 100)
                return BadRequest("Percentual de comissão não pode ser maior que 100%");

            if (Promocao.MesInicio <= 0 || Promocao.MesInicio > 12)
                return BadRequest("Mês Inicial inválido !");

            if (Promocao.MesFinal <= 0 || Promocao.MesFinal > 12)
                return BadRequest("Mês Final inválido !");

            if (Promocao.AnoInicio <= 1901 || Promocao.AnoInicio > DateTime.Today.Year)
                return BadRequest("Ano Inicial inválido !");

            if (Promocao.AnoFinal <= 1901 || Promocao.AnoFinal > DateTime.Today.Year)
                return BadRequest("Ano Final inválido !");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadosproduto = Banco.ConsultarProduto(Promocao.Produto);

            if (dadosproduto != null)
            {
                idProduto = dadosproduto.IdProduto;
            }
            else
            {
                return BadRequest("Produto não cadastrado !");
            }

            PromocaoProduto promocao = new PromocaoProduto();
            promocao.IdProduto = idProduto;
            promocao.AnoMesInicioVigencia = Promocao.AnoInicio.ToString() + Promocao.MesInicio.ToString().PadLeft(2, '0');
            promocao.AnoMesFinalVigencia = Promocao.AnoFinal.ToString() + Promocao.MesFinal.ToString().PadLeft(2,'0');
            promocao.PercComissao = Promocao.Comissao;

            if (Int32.Parse(promocao.AnoMesFinalVigencia) < Int32.Parse(promocao.AnoMesInicioVigencia))
                return BadRequest("Vigência Final precisa ser superior a Vigência Inicial !");

            var dados = Banco.ConsultarPromocaoProduto(promocao);

            if (dados != null)
            {
                return BadRequest("Promoção já cadastrada !");
            }
            else
            {
                Banco.GravarPromocaoProduto(promocao);
                mensagem = "Promoção do Produto " + Promocao.Produto + " incluida com sucesso";
            }

            return Ok(mensagem);
        }

    }
}
