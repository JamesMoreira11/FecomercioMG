﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;
using System.Data;
using Moq;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class RecebimentoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public RecebimentoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult BaixarBoletos(BaixarBoleto Recebimento)
        {
            int idCliente = 0;
            string AnoMes = "";
            string mensagem = "";

            Boleto boleto = new Boleto();

            if (Recebimento.Cliente == null)
                return BadRequest("Nome do Cliente precisa ser informado");

            if (Recebimento.Mes <= 0 || Recebimento.Mes > 12)
                return BadRequest("Mês de referência inválido !");

            if (Recebimento.Ano <= 1901 || Recebimento.Ano > DateTime.Today.Year)
                return BadRequest("Ano de referência inválido !");

            if (Recebimento.Valor <= 0)
                return BadRequest("Valor recebido inválido");

            AnoMes = Recebimento.Ano.ToString() + Recebimento.Mes.ToString().PadLeft(2, '0');

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadoscliente = Banco.ConsultarCliente(Recebimento.Cliente);

            if (dadoscliente != null)
            {
                idCliente = dadoscliente.IdCliente;
                boleto.IdCliente = idCliente;
                boleto.QtdeFuncionarios = dadoscliente.QtdeFuncionarios;
                boleto.CapitalSocial = dadoscliente.CapitalSocial;
            }
            else
            {
                return BadRequest("Cliente não cadastrado !");
            }

            var dadosboleto = Banco.ObterBoleto(idCliente, AnoMes);

            if (dadosboleto == null)
            {
                return BadRequest("Boleto do mês de referência não encontrado !");
            }

            boleto.IdBoleto = dadosboleto.IdBoleto;
            boleto.AnoMes = AnoMes;
            boleto.CodStatus = 4;
            boleto.ValorBoleto = dadosboleto.ValorBoleto;
            boleto.ValorPago = Recebimento.Valor;
            boleto.ValorAberto = boleto.ValorBoleto - boleto.ValorPago;
            boleto.ValorAdicional = 0;
            boleto.DataPagamento = Recebimento.dataPagamento.ToString("dd/MM/yyyy");
            boleto.DataVencimento = dadosboleto.DataVencimento;

            Banco.AtualizarBoleto(boleto);
            mensagem = "Boleto " + boleto.IdBoleto.ToString() + " - Vencimento : " + boleto.DataVencimento + " - Valor : " + boleto.ValorBoleto.ToString("N2");

            return Ok(mensagem);
        }

    }
}
