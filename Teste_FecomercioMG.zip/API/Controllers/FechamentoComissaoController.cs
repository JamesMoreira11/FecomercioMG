﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;
using System.Data;
using Moq;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class FechamentoComissaoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public FechamentoComissaoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult FechamentoComissao(CalcularComissao Comissao)
        {
            string AnoMes = "";
            string mensagem = "";

            if (Comissao.Mes <= 0 || Comissao.Mes > 12)
                return BadRequest("Mês de referência inválido !");

            if (Comissao.Ano <= 1901 || Comissao.Ano > DateTime.Today.Year)
                return BadRequest("Ano de referência inválido !");

            AnoMes = Comissao.Ano.ToString() + Comissao.Mes.ToString().PadLeft(2, '0');

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            Banco.ExcluirComissao(AnoMes);

            Banco.GravarComissao(Comissao.Mes.ToString(), Comissao.Ano.ToString());

            mensagem = "Comissão gerada com sucesso";

            return Ok(mensagem);
        }

        [HttpGet]
        public IActionResult ObterComissao(ConsultarComissao Comissao)
        {
            int idVendedor = 0;
            string AnoMes = "";

            if (Comissao.Vendedor == null)
                return BadRequest("Nome do Vendedor precisa ser informado");

            if (Comissao.Mes <= 0 || Comissao.Mes > 12)
                return BadRequest("Mês de referência inválido !");

            if (Comissao.Ano <= 1901 || Comissao.Ano > DateTime.Today.Year)
                return BadRequest("Ano de referência inválido !");

            AnoMes = Comissao.Ano.ToString() + Comissao.Mes.ToString().PadLeft(2, '0');

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadosvendedor = Banco.ConsultarVendedor(Comissao.Vendedor);

            if (dadosvendedor != null)
            {
                idVendedor = dadosvendedor.IdVendedor;
            }
            else
            {
                return BadRequest("Vendedor não cadastrado !");
            }

            var dados = Banco.ObterComissao(idVendedor, AnoMes);

            if (dados == null)
            {
                return BadRequest("Não existem comissões calculadas para esse vendedor !");
            }

            return Ok(dados);
        }

    }
}
