﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class ClienteController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public ClienteController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult CadastrarCliente(CadastrarClientes Clientes)
        {
            int idVendedor = 0;
            string mensagem = "";

            if (Clientes.RazaoSocial == null)
                return BadRequest("Razão Social precisa ser informada");

            if (Clientes.Vendedor == null)
                return BadRequest("Nome do Vendedor precisa ser informado");

            if (Clientes.Funcionarios <= 0)
                return BadRequest("Quantidade de Funcionarios invalida");

            if (Clientes.CapitalSocial <= 0)
                return BadRequest("Capital Social invalido");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadosvendedor = Banco.ConsultarVendedor(Clientes.Vendedor);

            if (dadosvendedor != null)
            {
                idVendedor = dadosvendedor.IdVendedor;
            }
            else
            {
                Banco.GravarVendedor(Clientes.Vendedor);
                dadosvendedor = Banco.ConsultarVendedor(Clientes.Vendedor);
                if (dadosvendedor != null)
                {
                    idVendedor = dadosvendedor.IdVendedor;
                }
            }

            Cliente cliente = new Cliente();
            cliente.IdVendedor = idVendedor;
            cliente.RazaoSocial = Clientes.RazaoSocial;
            cliente.QtdeFuncionarios = Clientes.Funcionarios;
            cliente.CapitalSocial = Clientes.CapitalSocial;

            var dados = Banco.ConsultarCliente(Clientes.RazaoSocial);

            if (dados != null)
            {
                cliente.IdCliente = dados.IdCliente;
                Banco.AtualizarCliente(cliente);
                mensagem = "Cliente " + cliente.IdCliente.ToString() + " - " + cliente.RazaoSocial + ", atualizado com sucesso";
            }
            else
            {
                Banco.GravarCliente(cliente);
                mensagem = "Cliente " + cliente.RazaoSocial + " incluido com sucesso";
            }

            return Ok(mensagem);
        }
    }
}
