﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class PrecoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public PrecoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult PrecoProduto(CadastrarPrecos Precos)
        {
            int idProduto = 0;
            string mensagem = "";

            if (Precos.Produto == null)
                return BadRequest("Descrição do produto precisa ser informada");

            if (Precos.IdIndicador != 1 && Precos.IdIndicador != 2)
                return BadRequest("Indicador invalido !");

            if (Precos.QtdeAte < Precos.QtdeDe)
                return BadRequest("Intervalo de quantidades invalido");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadosproduto = Banco.ConsultarProduto(Precos.Produto);

            if (dadosproduto != null)
            {
                idProduto = dadosproduto.IdProduto;
            }
            else
            {
                return BadRequest("Produto não cadastrado !");
            }

            PrecoProduto preco = new PrecoProduto();
            preco.IdProduto = idProduto;
            preco.IdIndicador = Precos.IdIndicador;
            preco.QtdeDe = Precos.QtdeDe;
            preco.QtdeAte = Precos.QtdeAte;
            preco.Valor = Precos.Valor;

            var dados = Banco.ConsultarPrecoProduto(preco);

            if (dados != null)
            {
                return BadRequest("Preço já cadastrado !");
            }
            else
            {
                Banco.GravarPrecoProduto(preco);
                mensagem = "Preço do Produto " + Precos.Produto + " incluido com sucesso";
            }

            return Ok(mensagem);
        }

    }
}
