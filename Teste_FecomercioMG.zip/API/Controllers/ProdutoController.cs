﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class ProdutoController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public ProdutoController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult CadastrarProduto(CadastrarProdutos Produtos)
        {
            int idCategoria = 0;
            string mensagem = "";

            if (Produtos.Produto == null)
                return BadRequest("Descrição do produto precisa ser informada");

            if (Produtos.Comissao <= 0)
                return BadRequest("Percentual comissão invalido");

            if (Produtos.Comissao >= 100)
                return BadRequest("Percentual comissão não pode ser maior que 100%");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadoscategoria = Banco.ConsultarCategoria(Produtos.Categoria);

            if (dadoscategoria != null)
            {
                idCategoria = dadoscategoria.IdCategoria;
            }
            else
            {
                return BadRequest("Descrição da Categoria não encontrada");
            }

            Produto produto = new Produto();
            produto.IdCategoria = idCategoria;
            produto.Descricao = Produtos.Produto;
            produto.PercComissao = Produtos.Comissao;

            var dados = Banco.ConsultarProduto(Produtos.Produto);

            if (dados != null)
            {
                produto.IdProduto = dados.IdProduto;
                Banco.AtualizarProduto(produto);
                mensagem = "Produto " + produto.IdProduto.ToString() + " - " + produto.Descricao + ", atualizado com sucesso";
            }
            else
            {
                Banco.GravarProduto(produto);
                mensagem = "Produto " + produto.Descricao + " incluido com sucesso";
            }

            return Ok(mensagem);
        }
    }
}
