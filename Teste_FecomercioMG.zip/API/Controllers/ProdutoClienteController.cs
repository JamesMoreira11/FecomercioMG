﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using NSubstitute.Routing.Handlers;
using API.DTOs;
using API.Infrastructure.Sqlite;
using Microsoft.Extensions.Logging;
using API.Infrastructure.Database.CommandStore.Requests;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [Consumes("application/json")]
    [Produces("application/json")]

    public class ProdutoClienteController : ControllerBase
    {
        private readonly DatabaseConfig _databaseConfig;
        public ProdutoClienteController(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        [HttpPost]
        public IActionResult ProdutoCliente(CadastrarProdutosClientes ProdCliente)
        {
            int idProduto = 0;
            int idCliente = 0;
            string mensagem = "";

            if (ProdCliente.Produto == null)
                return BadRequest("Descrição do produto precisa ser informada");

            if (ProdCliente.Cliente == null)
                return BadRequest("Nome do Cliente precisa ser informado");

            DatabaseBootstrap Banco = new DatabaseBootstrap(_databaseConfig);

            var dadosproduto = Banco.ConsultarProduto(ProdCliente.Produto);

            if (dadosproduto != null)
            {
                idProduto = dadosproduto.IdProduto;
            }
            else
            {
                return BadRequest("Produto não cadastrado !");
            }

            var dadoscliente = Banco.ConsultarCliente(ProdCliente.Cliente);

            if (dadoscliente != null)
            {
                idCliente = dadoscliente.IdCliente;
            }
            else
            {
                return BadRequest("Cliente não cadastrado !");
            }

            ProdutoCliente produtos = new ProdutoCliente();

            produtos.IdProduto = idProduto;
            produtos.IdCliente = idCliente;

            var dados = Banco.ConsultarProdutoCliente(produtos);

            if (dados != null)
            {
                return BadRequest("Produto já cadastrado para o cliente !");
            }
            else
            {
                Banco.GravarProdutoCliente(produtos);
                mensagem = "Produto " + ProdCliente.Produto + " cadastrado para o cliente : " + ProdCliente.Cliente;
            }

            return Ok(mensagem);
        }

    }
}
