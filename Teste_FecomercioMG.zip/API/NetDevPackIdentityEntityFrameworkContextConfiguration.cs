﻿using Microsoft.EntityFrameworkCore;

internal class NetDevPackIdentityEntityFrameworkContextConfiguration
{
    internal static void Instance(DbContextOptionsBuilder builder)
    {
        throw new NotImplementedException();
    }
}