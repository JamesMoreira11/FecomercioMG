﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarProdutos
    {
        public string? Produto { get; set; }
        public string? Categoria  { get; set; }
        public double Comissao { get; set; }
    }
}
