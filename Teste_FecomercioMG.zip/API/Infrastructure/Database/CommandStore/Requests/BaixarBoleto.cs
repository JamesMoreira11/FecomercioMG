﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class BaixarBoleto
    {
        public string? Cliente { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
        public DateTime dataPagamento { get; set; }
        public double Valor { get; set; }
    }
}
