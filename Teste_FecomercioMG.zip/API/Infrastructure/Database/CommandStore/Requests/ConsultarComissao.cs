﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class ConsultarComissao
    {
        public string? Vendedor { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
    }
}
