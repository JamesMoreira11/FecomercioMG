﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarPrecos
    {
        public string? Produto { get; set; }
        public int IdIndicador { get; set; }
        public double QtdeDe { get; set; }
        public double QtdeAte { get; set; }
        public double Valor { get; set; }

    }
}
