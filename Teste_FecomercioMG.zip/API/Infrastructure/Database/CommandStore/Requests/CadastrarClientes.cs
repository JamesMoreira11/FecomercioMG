﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarClientes
    {
        public string? RazaoSocial { get; set; }
        public int Funcionarios { get; set; }
        public double CapitalSocial { get; set; }
        public string Vendedor { get; set; }

    }
}
