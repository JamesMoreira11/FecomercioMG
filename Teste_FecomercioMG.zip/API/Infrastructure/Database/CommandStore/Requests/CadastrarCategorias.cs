﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarCategorias
    {
        public string? Categoria { get; set; }
        public double Comissao { get; set; }
    }
}
