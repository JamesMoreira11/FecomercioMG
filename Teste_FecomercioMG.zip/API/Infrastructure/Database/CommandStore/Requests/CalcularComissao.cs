﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CalcularComissao
    {
        public int Mes { get; set; }
        public int Ano { get; set; }
    }
}
