﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class GerarBoleto
    {
        public string? RazaoSocial { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }
    }
}
