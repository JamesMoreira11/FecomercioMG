﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarPromocao
    {
        public string? Produto { get; set; }
        public int MesInicio { get; set; }
        public int AnoInicio { get; set; }
        public int MesFinal { get; set; }
        public int AnoFinal { get; set; }
        public double Comissao { get; set; }

    }
}
