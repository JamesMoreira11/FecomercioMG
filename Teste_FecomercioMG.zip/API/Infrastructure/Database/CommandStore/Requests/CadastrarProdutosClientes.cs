﻿namespace API.Infrastructure.Database.CommandStore.Requests
{
    public class CadastrarProdutosClientes
    {
        public string? Produto { get; set; }
        public string? Cliente { get; set; }
    }
}
