﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Data;
using System.Drawing;

namespace API.Infrastructure.Sqlite
{
    public class DatabaseBootstrap : IDatabaseBootstrap
    {
        private readonly DatabaseConfig databaseConfig;

        public DatabaseBootstrap(DatabaseConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public void Setup()
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            var table = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND (name = 'boleto' or name = 'boletodetalhe' or name = 'categoria' or name = 'cliente' or name = 'precoproduto' or name = 'produto' or name = 'promocaoproduto' or name = 'vendedor' or name = 'comissao');");
            var tableName = table.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableName) && (tableName == "boleto" || tableName == "boletodetalhe" || tableName == "categoria" || tableName == "cliente" || tableName == "precoproduto" || tableName == "produto" || tableName == "promocaoproduto" || tableName == "vendedor" || tableName == "comissao"))
                return;

            connection.Execute("CREATE TABLE vendedor ( " +
                               "IdVendedor INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "nome TEXT(100) NOT NULL UNIQUE " +
                               ");");

            connection.Execute("CREATE TABLE cliente ( " +
                               "IdCliente INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "razaosocial TEXT(100) NOT NULL UNIQUE," +
                               "qtdefuncionarios INTEGER(10) NOT NULL default 0," +
                               "capitalsocial REAL(14) NOT NULL default 0," +
                               "idvendedor INTEGER NOT NULL default 0," +
                               "ativo INTEGER(1) NOT NULL default 0," +
                               "CHECK(ativo in (0, 1)), " +
                               "FOREIGN KEY(idvendedor) REFERENCES vendedor(idvendedor) " +
                               ");");

            connection.Execute("CREATE TABLE categoria ( " +
                               "IdCategoria INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "descricao TEXT(100) NOT NULL UNIQUE," +
                               "percomissao REAL(10) NOT NULL default 0" +
                               ");");

            connection.Execute("CREATE TABLE produto ( " +
                               "IdProduto INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "descricao TEXT(100) NOT NULL UNIQUE," +
                               "idcategoria INTEGER NOT NULL default 0," +
                               "percomissao REAL(10) NOT NULL default 0,  " +
                               "FOREIGN KEY(idcategoria) REFERENCES categoria(idcategoria) " +
                               ");");

            connection.Execute("CREATE TABLE precoproduto ( " +
                               "IdPreco INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idproduto INTEGER NOT NULL default 0," +
                               "idindicador INTEGER NOT NULL default 1," +
                               "qtdede REAL(14) NOT NULL default 0," +
                               "qtdeate REAL(14) NOT NULL default 0," +
                               "valor REAL(14) NOT NULL default 0, " +
                               "CHECK(idindicador in (1, 2)), " +
                               "FOREIGN KEY(idproduto) REFERENCES produto(idproduto) " +
                               ");");

            connection.Execute("CREATE TABLE promocaoproduto ( " +
                               "IdPromocao INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idproduto INTEGER NOT NULL default 0," +
                               "anomesiniciovigencia TEXT(06) NOT NULL default '190001'," +
                               "anomesfinalvigencia TEXT(06) NOT NULL default '299912'," +
                               "percomissao REAL(10) NOT NULL default 0," +
                               "FOREIGN KEY(idproduto) REFERENCES produto(idproduto) " +
                               ");");

            connection.Execute("CREATE TABLE boleto ( " +
                               "IdBoleto INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idcliente INTEGER NOT NULL default 0," +
                               "anomes TEXT(06) NOT NULL," +
                               "codstatus INTEGER NOT NULL default 1," +
                               "qtdefuncionarios INTEGER(10) NOT NULL default 0," +
                               "capitalsocial REAL(14) NOT NULL default 0," +
                               "valorboleto REAL(14) NOT NULL default 0," +
                               "datavencimento TEXT(10)," +
                               "datapagamento TEXT(10)," +
                               "datacancelamento TEXT(10)," +
                               "valorpago REAL(14) NOT NULL default 0," +
                               "valoraberto REAL(14) NOT NULL default 0," +
                               "valoradicional REAL(14) NOT NULL default 0," +
                               "FOREIGN KEY(idcliente) REFERENCES cliente(idcliente) " +
                               ");");

            connection.Execute("CREATE TABLE boletodetalhe ( " +
                               "IdBoletoDetalhe INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idboleto INTEGER NOT NULL default 0," +
                               "idcliente INTEGER NOT NULL default 0," +
                               "idproduto INTEGER NOT NULL default 0," +
                               "anomes TEXT(06) NOT NULL," +
                               "idindicador INTEGER NOT NULL default 1," +
                               "qtdefuncionarios INTEGER(10) NOT NULL default 0," +
                               "capitalsocial REAL(14) NOT NULL default 0," +
                               "valorfaturado REAL(14) NOT NULL default 0," +
                               "FOREIGN KEY(idboleto) REFERENCES boleto(idboleto) " +
                               ");");

            connection.Execute("CREATE TABLE comissao ( " +
                               "IdComissao INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idvendedor INTEGER NOT NULL default 0," +
                               "anomes TEXT(06) NOT NULL," +
                               "valorfaturamento REAL(14) NOT NULL default 0," +
                               "valorcomissao REAL(14) NOT NULL default 0," +
                               "FOREIGN KEY(idvendedor) REFERENCES vendedor(idvendedor) " +
                               ");");

            connection.Execute("CREATE TABLE produtocliente ( " +
                               "IdProdutoCliente INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                               "idcliente INTEGER NOT NULL default 0," +
                               "idproduto INTEGER NOT NULL default 0" +
                               ");");
        }
        public string GravarVendedor(string NomeVendedor)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Nome", NomeVendedor);

            var reg = connection.Execute("Insert Into vendedor (nome) Values (@Nome);", pars);

            return reg.ToString();
        }
        public Vendedor ConsultarVendedor(string NomeVendedor)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@nome", NomeVendedor);

            string sql = @"Select idvendedor, nome from vendedor where nome = @nome;";

            var consulta = connection.QueryFirstOrDefault<Vendedor>(sql, parameter);

            return consulta;
        }
        public string GravarCliente(Cliente dados)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Nome", dados.RazaoSocial);
            pars.Add("@QtdeFunc", dados.QtdeFuncionarios);
            pars.Add("@Capital", dados.CapitalSocial);
            pars.Add("@Vendedor", dados.IdVendedor);
            pars.Add("@Ativo", 1);

            var reg = connection.Execute("Insert Into cliente (razaosocial, qtdefuncionarios, capitalsocial, idvendedor, ativo) Values (@Nome, @QtdeFunc, @Capital, @Vendedor, @Ativo);", pars);

            return reg.ToString();
        }
        public string AtualizarCliente(Cliente dados)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Cliente", dados.IdCliente);
            pars.Add("@Nome", dados.RazaoSocial);
            pars.Add("@QtdeFunc", dados.QtdeFuncionarios);
            pars.Add("@Capital", dados.CapitalSocial);
            pars.Add("@Vendedor", dados.IdVendedor);
            pars.Add("@Ativo", 1);

            var reg = connection.Execute("Update cliente Set razaosocial = @Nome, qtdefuncionarios = @QtdeFunc, capitalsocial = @Capital, idvendedor = @Vendedor, ativo = @Ativo Where idcliente = @Cliente;", pars);

            return reg.ToString();
        }
        public Cliente ConsultarCliente(string NomeCliente)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@nome", NomeCliente);

            string sql = @"Select idcliente, razaosocial, qtdefuncionarios, capitalsocial, idvendedor, ativo from cliente where razaosocial = @nome;";

            var consulta = connection.QueryFirstOrDefault<Cliente>(sql, parameter);

            return consulta;
        }
        public string GravarCategoria(string NomeCategoria, double PercComissao)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Nome", NomeCategoria);
            pars.Add("@Comissao", PercComissao);

            var reg = connection.Execute("Insert Into categoria (descricao, percomissao) Values (@Nome, @Comissao);", pars);

            return reg.ToString();
        }
        public string AtualizarCategoria(string NomeCategoria, double PercComissao)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Nome", NomeCategoria);
            pars.Add("@Comissao", PercComissao);

            var reg = connection.Execute("Update categoria Set percomissao = @Comissao Where descricao = @Nome;", pars);

            return reg.ToString();
        }
        public Categoria ConsultarCategoria(string NomeCategoria)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@nome", NomeCategoria);

            string sql = @"Select idcategoria, descricao, percomissao from categoria where descricao = @nome;";

            var consulta = connection.QueryFirstOrDefault<Categoria>(sql, parameter);

            return consulta;
        }
        public Categoria ObterCategoria(int IdCategoria)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Id", IdCategoria);

            string sql = @"Select idcategoria, descricao, percomissao from categoria where idcategoria = @Id;";

            var consulta = connection.QueryFirstOrDefault<Categoria>(sql, parameter);

            return consulta;
        }
        public string GravarProduto(Produto produto)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Produto", produto.Descricao);
            pars.Add("@Comissao", produto.PercComissao);
            pars.Add("@Categoria", produto.IdCategoria);

            var reg = connection.Execute("Insert Into produto (descricao, percomissao, idcategoria) Values (@Produto, @Comissao, @Categoria);", pars);

            return reg.ToString();
        }
        public string AtualizarProduto(Produto produto)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@IdProduto", produto.IdProduto);
            pars.Add("@Produto", produto.Descricao);
            pars.Add("@Comissao", produto.PercComissao);
            pars.Add("@Categoria", produto.IdCategoria);

            var reg = connection.Execute("Update produto Set descricao = @Produto, percomissao = @Comissao, idcategoria = @Categoria Where idproduto = @Produto;", pars);

            return reg.ToString();
        }
        public Produto ConsultarProduto(string NomeProduto)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@nome", NomeProduto);

            string sql = @"Select idproduto, descricao, idcategoria, percomissao from produto where descricao = @nome;";

            var consulta = connection.QueryFirstOrDefault<Produto>(sql, parameter);

            return consulta;
        }
        public Produto ObterProduto(int IdProduto)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Id", IdProduto);

            string sql = @"Select idproduto, descricao, idcategoria, percomissao from produto where idproduto = @Id;";

            var consulta = connection.QueryFirstOrDefault<Produto>(sql, parameter);

            return consulta;
        }
        public string GravarPrecoProduto(PrecoProduto Preco)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Produto", Preco.IdProduto);
            pars.Add("@Indicador", Preco.IdIndicador); 
            pars.Add("@QtdeDe", Preco.QtdeDe);
            pars.Add("@QtdeAte", Preco.QtdeAte);
            pars.Add("@Valor", Preco.Valor);

            var reg = connection.Execute("Insert Into precoproduto (idproduto, idindicador, qtdede, qtdeate, valor) Values (@Produto, @Indicador, @QtdeDe, @QtdeAte, @Valor);", pars);

            return reg.ToString();
        }
        public PrecoProduto ObterPrecoProduto(int IdProduto, int IdIndicador, double Qtde)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Produto", IdProduto);
            parameter.Add("@Indicador", IdIndicador);
            parameter.Add("@Qtde", Qtde);

            string sql = @"Select idpreco, idproduto, idindicador, qtdede, qtdeate, valor from precoproduto where idproduto = @Produto and idindicador = @Indicador and @Qtde between qtdede and qtdeate;";

            var consulta = connection.QueryFirstOrDefault<PrecoProduto>(sql, parameter);

            return consulta;
        }
        public PrecoProduto ConsultarPrecoProduto(PrecoProduto Preco)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Produto", Preco.IdProduto);
            parameter.Add("@Indicador", Preco.IdIndicador);
            parameter.Add("@QtdeDe", Preco.QtdeDe);
            parameter.Add("@QtdeAte", Preco.QtdeAte);

            string sql = @"Select idpreco, idproduto, idindicador, qtdede, qtdeate, valor from precoproduto where idproduto = @Produto and idindicador = @Indicador and qtdede = @QtdeDe and qtdeate = @QtdeAte;";

            var consulta = connection.QueryFirstOrDefault<PrecoProduto>(sql, parameter);

            return consulta;
        }
        public string GravarProdutoCliente(ProdutoCliente ProdCliente)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Produto", ProdCliente.IdProduto);
            pars.Add("@Cliente", ProdCliente.IdCliente);

            var reg = connection.Execute("Insert Into produtocliente (idproduto, idcliente) Values (@Produto, @Cliente);", pars);

            return reg.ToString();
        }
        public ProdutoCliente ConsultarProdutoCliente(ProdutoCliente Produtos)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Produto", Produtos.IdProduto);
            parameter.Add("@Cliente", Produtos.IdCliente);

            string sql = @"Select IdProdutoCliente, idproduto, idcliente from produtocliente where idproduto = @Produto and idcliente = @Cliente;";

            var consulta = connection.QueryFirstOrDefault<ProdutoCliente>(sql, parameter);

            return consulta;
        }
        public List<ProdutoCliente> PesquisarProdutoCliente (int IdCliente)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Cliente", IdCliente);

            string sql = @"Select IdProdutoCliente, idproduto, idcliente from produtocliente where idcliente =  @Cliente;";

            var consulta = connection.Query<ProdutoCliente>(sql, parameter);

            return (List<ProdutoCliente>)consulta;
        }
        public string GravarPromocaoProduto(PromocaoProduto Promocao)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Produto", Promocao.IdProduto);
            pars.Add("@Inicio", Promocao.AnoMesInicioVigencia);
            pars.Add("@Final", Promocao.AnoMesFinalVigencia);
            pars.Add("@Comissao", Promocao.PercComissao);
 
            var reg = connection.Execute("Insert Into promocaoproduto (idproduto, anomesiniciovigencia, anomesfinalvigencia, percomissao) Values (@Produto, @Inicio, @Final@, @Comissao);", pars);

            return reg.ToString();
        }
        public PromocaoProduto ObterPromocaoProduto(int IdProduto, string AnoMes)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Produto", IdProduto);
            parameter.Add("@AnoMes", AnoMes);

            string sql = @"Select idpromocao, idproduto, anomesiniciovigencia, anomesfinalvigencia, percomissao from promocaoproduto where idproduto = @Produto and @AnoMes between anomesiniciovigencia and anomesfinalvigencia;";

            var consulta = connection.QueryFirstOrDefault<PromocaoProduto>(sql, parameter);

            return consulta;
        }
        public PromocaoProduto ConsultarPromocaoProduto(PromocaoProduto Promocao)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Produto", Promocao.IdProduto);
            parameter.Add("@AnoMesInicio", Promocao.AnoMesInicioVigencia);
            parameter.Add("@AnoMesFinal", Promocao.AnoMesFinalVigencia);

            string sql = @"Select idpromocao, idproduto, anomesiniciovigencia, anomesfinalvigencia, percomissao from promocaoproduto where idproduto = @Produto and anomesiniciovigencia = @AnoMesInicio and anomesfinalvigencia = @AnoMesFinal;";

            var consulta = connection.QueryFirstOrDefault<PromocaoProduto>(sql, parameter);

            return consulta;
        }
        public string GravarBoleto(Boleto dados)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Cliente", dados.IdCliente);
            pars.Add("@AnoMes", dados.AnoMes);
            pars.Add("@QtdeFunc", dados.QtdeFuncionarios);
            pars.Add("@Capital", dados.CapitalSocial);
            pars.Add("@Valor", dados.ValorBoleto);
            pars.Add("@Vencimento", dados.DataVencimento);
            pars.Add("@Adicional", dados.ValorAdicional);

            var reg = connection.Execute("Insert Into boleto (idcliente, anomes, codstatus, qtdefuncionarios, capitalsocial, valorboleto, datavencimento, valoraberto, valoradicional) Values (@Cliente, @AnoMes, 1, @QtdeFunc, @Capital, @Valor, @Vencimento, @Valor, @Adicional);", pars);

            return reg.ToString();
        }
        public string AtualizarBoleto(Boleto dados)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Boleto", dados.IdBoleto);
            pars.Add("@Cliente", dados.IdCliente);
            pars.Add("@AnoMes", dados.AnoMes);
            pars.Add("@QtdeFunc", dados.QtdeFuncionarios);
            pars.Add("@Capital", dados.CapitalSocial);
            pars.Add("@Status", dados.CodStatus);
            pars.Add("@Valor", dados.ValorBoleto);
            pars.Add("@ValorPago", dados.ValorPago);
            pars.Add("@ValorAberto", dados.ValorAberto);
            pars.Add("@Vencimento", dados.DataVencimento);
            pars.Add("@DataPagamento", dados.DataPagamento);
            pars.Add("@Adicional", dados.ValorAdicional);

            var reg = connection.Execute("Update boleto set codstatus = @Status, valorboleto = @Valor, valoraberto = @ValorAberto, valoradicional = @Adicional, valorpago = @ValorPago, datapagamento = @DataPagamento Where idboleto = @Boleto;", pars);

            return reg.ToString();
        }
        public Boleto ObterBoleto(int IdCliente, string AnoMes)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Cliente", IdCliente);
            parameter.Add("@AnoMes", AnoMes);

            string sql = @"Select idboleto, idcliente, anomes, codstatus, qtdefuncionarios, capitalsocial, valorboleto, datavencimento, datapagamento, datacancelamento, valorpago, valoraberto, valoradicional from boleto where idcliente = @Cliente and anomes = @AnoMes;";

            var consulta = connection.QueryFirstOrDefault<Boleto>(sql, parameter);

            return consulta;
        }
        public Boleto ConsultarBoleto(int IdBoleto)
        {

            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Boleto", IdBoleto);

            string sql = @"Select idboleto, idcliente, anomes, codstatus, qtdefuncionarios, capitalsocial, valorboleto, datavencimento, datapagamento, datacancelamento, valorpago, valoraberto, valoradicional from boleto where idboleto = @Boleto;";

            var consulta = connection.QueryFirstOrDefault<Boleto>(sql, parameter);

            return consulta;
        }
        public string GravarDetalheBoleto(BoletoDetalhe dados)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@Boleto", dados.IdBoleto);
            pars.Add("@Cliente", dados.IdCliente);
            pars.Add("@Produto", dados.IdProduto);
            pars.Add("@AnoMes", dados.AnoMes);
            pars.Add("@Indicador", dados.IdIndicador);
            pars.Add("@QtdeFunc", dados.QtdeFuncionarios);
            pars.Add("@Capital", dados.CapitalSocial);
            pars.Add("@Valor", dados.ValorFaturado);

            var reg = connection.Execute("Insert Into boletodetalhe (idboleto, idcliente, idproduto, anomes, idindicador, qtdefuncionarios, capitalsocial, valorfaturado) Values (@Boleto, @Cliente, @Produto, @AnoMes, @Indicador, @QtdeFunc, @Capital, @Valor);", pars);

            return reg.ToString();
        }
        public string GravarComissao(string Mes, string Ano)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@MesAno", Mes.PadLeft(2, '0') + "/" + Ano.ToString());
            pars.Add("@AnoMes", Ano.ToString() + Mes.PadLeft(2, '0'));

            string sql = "insert into comissao (idvendedor, anomes, valorfaturamento, valorcomissao)  " +
                 "select dd.idvendedor, @AnoMes as anomes, sum(bb.valorfaturado) as faturado, " +
                 "       sum((bb.valorfaturado * (case when ee.percomissao is null then (case when cc.percomissao > pp.percomissao then cc.percomissao else pp.percomissao end) else ee.percomissao end)) / 100) " +
                 "  From boleto aa " +
                 "inner join boletodetalhe bb on (bb.idboleto = aa.idboleto) " +
                 "inner join produto pp on (pp.IdProduto = bb.idproduto) " +
                 "inner join categoria cc on (cc.IdCategoria = pp.idcategoria) " +
                 "inner join cliente dd on (dd.IdCliente = aa.idcliente) " +
                 "left outer join promocaoproduto ee on (ee.idproduto = bb.idproduto and bb.anomes between ee.anomesiniciovigencia and ee.anomesfinalvigencia) " +
                 "Where aa.codstatus = 4 " +
                 "  and substr(aa.datapagamento, 4, 7) = @MesAno;";

            var reg = connection.Execute(sql, pars);

            return reg.ToString();
        }
        public string ExcluirComissao(string AnoMes)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var pars = new DynamicParameters();
            pars.Add("@AnoMes", AnoMes);

            var reg = connection.Execute("Delete From comissao Where anomes = @AnoMes;", pars);

            return reg.ToString();
        }
        public Comissao ObterComissao(int IdVendedor, string AnoMes)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            if (connection.State == System.Data.ConnectionState.Closed)

                connection.Open();

            var parameter = new DynamicParameters();
            parameter.Add("@Vendedor", IdVendedor);
            parameter.Add("@AnoMes", AnoMes);

            string sql = @"Select IdComissao, idvendedor, anomes, valorfaturamento, valorcomissao from comissao where idvendedor = @Vendedor and anomes = @AnoMes;";

            var consulta = connection.QueryFirstOrDefault<Comissao>(sql, parameter);

            return consulta;
        }
    }
}
