﻿namespace API.Infrastructure.Sqlite
{
    public class Comissao
    {
        public int IdComissao { get; set; }
        public int IdVendedor { get; set; }
        public string AnoMes { get; set; } = string.Empty;
        public double ValorFaturamento { get; set; }
        public double ValorComissao { get; set; }
    }
}
