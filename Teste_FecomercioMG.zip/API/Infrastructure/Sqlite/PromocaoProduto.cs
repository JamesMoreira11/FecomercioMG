﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class PromocaoProduto
    {
        public int IdPromocao { get; set; }
        public int IdProduto { get; set; }
        public string AnoMesInicioVigencia { get; set; } = string.Empty;
        public string AnoMesFinalVigencia { get; set; } = string.Empty;
        public double PercComissao { get; set; }
    }
}
