﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class Cliente
    {
        public int IdCliente { get; set; }
        public string RazaoSocial { get; set; } = string.Empty;
        public int QtdeFuncionarios { get; set; }
        public double CapitalSocial { get; set; }
        public int IdVendedor { get; set; }
        public int Ativo { get; set; }
    }
}
