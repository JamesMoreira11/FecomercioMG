﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class PrecoProduto
    {
        public int IdPreco { get; set; }
        public int IdProduto { get; set; }
        public int IdIndicador { get; set; }
        public double QtdeDe { get; set; }
        public double QtdeAte { get; set; }
        public double Valor { get; set; }
    }
}
