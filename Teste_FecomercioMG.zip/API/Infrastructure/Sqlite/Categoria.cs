﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string Descricao { get; set; } = string.Empty;
        public double PercComissao { get; set; }
    }
}
