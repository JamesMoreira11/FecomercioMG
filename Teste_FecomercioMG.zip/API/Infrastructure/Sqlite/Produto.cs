﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class Produto
    {
        public int IdProduto { get; set; }
        public string Descricao { get; set; } = string.Empty;
        public int IdCategoria { get; set; }
        public double PercComissao { get; set; }
    }
}
