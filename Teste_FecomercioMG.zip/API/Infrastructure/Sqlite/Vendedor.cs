﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class Vendedor
    {
        public int IdVendedor { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
