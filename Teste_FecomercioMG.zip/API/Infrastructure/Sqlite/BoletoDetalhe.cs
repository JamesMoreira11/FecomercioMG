﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class BoletoDetalhe
    {
        public int IdBoletoDetalhe { get; set; }
        public int IdBoleto { get; set; }
        public int IdCliente { get; set; }
        public int IdProduto { get; set; }
        public string AnoMes { get; set; } = string.Empty;
        public int IdIndicador { get; set; }
        public int QtdeFuncionarios { get; set; }
        public double CapitalSocial { get; set; }
        public double ValorFaturado { get; set; }
    }
}
