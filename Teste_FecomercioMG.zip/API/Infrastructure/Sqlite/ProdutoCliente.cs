﻿namespace API.Infrastructure.Sqlite
{
    public class ProdutoCliente
    {
        public int idProdutoCliente { get; set; }
        public int IdCliente { get; set; }
        public int IdProduto { get; set; }

    }
}
