﻿using Microsoft.Data.Sqlite;

namespace API.Infrastructure.Sqlite
{
    public class Boleto
    {
        public int IdBoleto { get; set; }
        public int IdCliente { get; set; }
        public string AnoMes { get; set; } = string.Empty;
        public int CodStatus { get; set; }
        public int QtdeFuncionarios { get; set; }
        public double CapitalSocial { get; set; }
        public double ValorBoleto { get; set; }
        public string DataVencimento { get; set; } = string.Empty;
        public string DataPagamento { get; set; }=string.Empty;
        public string DataCancelamento { get; set; } = string.Empty;
        public double ValorPago { get; set; }
        public double ValorAberto { get; set; }
        public double ValorAdicional { get; set; }
    }
}
