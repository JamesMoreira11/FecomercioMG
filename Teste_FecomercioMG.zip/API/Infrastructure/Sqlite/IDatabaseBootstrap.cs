﻿namespace API.Infrastructure.Sqlite
{
    public interface IDatabaseBootstrap
    {
        void Setup();
    }
}