﻿namespace API.DTOs
{
    public class UserRequest
    {
        public string Numero { get; set; }

    }
}
